#include "mbed.h"
PwmOut led(p5);
PwmOut speaker(p21);

void play_tone(float frequency, float volume, int interval, int rest) {
    speaker.period(1.0 / frequency);
    speaker = volume;
    wait(interval);
    speaker = 0.0;
    wait(rest);
}

int main() {
    led = 0;
    while(1) {
        led = led + 0.10;
        printf("LED is now at %.2f\n", led.read());
        printf("Speaker is now at volume %.2f\n\n", led.read());
        play_tone(150.0, led, 1, 0);
        wait(0.2);
        if(led == 1.0) {
            led = 0;
        }
    }
}