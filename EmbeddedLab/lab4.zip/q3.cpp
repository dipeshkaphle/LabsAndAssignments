#include "mbed.h"
AnalogIn p(p15);
PwmOut led(p6), led2(p7);
PwmOut speaker(p21);
InterruptIn btn(p5);

void play_tone(float frequency, float volume, int interval, int rest) {
    speaker.period(1.0 / frequency);
    speaker = volume;
    wait(interval);
    speaker = 0.0;
    wait(rest);
}

void handleOn(){
    printf("Switch Turned On\n");
    led = 0;
    led2 = 0;
    while(1) {
        float rate = p.read();
        led = led + rate;
        led2 = led2 + rate;
        printf("\tLED1 is now at %.2f\n", led.read());
        printf("\tLED2 is now at %.2f\n", led2.read());
        printf("\tSpeaker is now at volume %.2f\n\n", led.read());
        play_tone(150.0, led.read(), 1, 0);
        wait(0.2);
        if(led >= 1.0) {
            led = 0;
        }
        if(led2 >= 1.0){
            led2 = 0;
        }
    }
}

void handleOff(){
    printf("Switch Turned Off\n");
    led = 1;
    led2 = 1;
    while(1){
        led = led - p.read();
        led2 = led2 - p.read();
        printf("\tLED1 is now at %.2f\n", led.read());
        printf("\tLED2 is now at %.2f\n", led2.read());
        printf("\tSpeaker is now at volume %.2f\n\n", led.read());
        play_tone(150.0, led.read(), 1, 0);
        wait(0.2);
        if(led <= 0) {
            led = 1.0;
        }
        if(led2 <= 0){
            led2 = 1.0;
        }
    }
}

int main() {
   btn.rise(&handleOn);
   btn.fall(&handleOff);
}