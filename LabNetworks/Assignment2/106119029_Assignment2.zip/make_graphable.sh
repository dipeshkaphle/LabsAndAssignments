awk '{print $1 $7}' cwnd-tcp-wired.out > graph_file
