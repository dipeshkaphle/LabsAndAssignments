#include <iostream>
#include <bits/stdc++.h>

using namespace std;

void strtok(string s, vector<string> &arr)
{
    stringstream ss(s);
    string word;
    while (ss >> word)
    {
        arr.push_back(word);
    }
}

class throughPut
{
    ofstream f;
    string filename;
    map<int,vector<float>> times;
    float prevtime;

public:
    //from node 3 for 3 odd numbers
    throughPut(string filename)
    {
        this->filename = filename;
        times[3] = vector<float>();
        times[5] = vector<float>();
        times[7] = vector<float>();
    }
    ~throughPut()
    {
        f.close();
    }

    void processPacketData(char event, float timestamp, int toNode,int seqNo){
        if(seqNo > 100) return;
        if(event == 'r' && toNode ==3 || toNode ==5 || toNode ==7){
                times[toNode].push_back(timestamp);
        }
    }

    void printValues(){
        float avg = 0;
        float sd = 0;
        float diff;
        f.open(filename + "_node3");
        for(int i=1;i<100;i++){
            diff = times[3][i]-times[3][i-1];
            avg += diff/100;
            sd += diff*diff/100;
            f<<i<<" "<<diff<<endl;
        }
        cout<<"avg for 3 is "<< avg << endl;
        cout<<"std for 3 is "<< sqrt(abs(sd - avg*avg))<<endl;
        f.close();
        sd = 0;
        avg = 0;
        f.open(filename + "_node5");
        for(int i=1;i<100;i++){
            diff = times[5][i]-times[5][i-1]; 
            avg += diff/100;
            sd += diff*diff/100;
            f<<i<<" "<<diff<<endl;
        }
        cout<<"avg for 5 is "<< avg << endl;
        cout<<"std for 5 is "<< sqrt(abs(sd - avg*avg))<<endl;
        f.close();
        avg =0;
        sd = 0;
        f.open(filename + "_node7");
        for(int i=1;i<100;i++){
            diff = times[7][i]-times[7][i-1];
            avg += diff/100;
            sd += diff*diff/100; 
            f<<i<<" "<<diff<<endl;
        }
        cout<<"avg for 7 is "<< avg << endl;
        cout<<"std for 7 is "<< sqrt(abs(sd - avg*avg))<<endl;
        f.close();
    }
};


int main(int argc, char **argv)
{
    //control variabels
    char event;
    float timestamp;
    int fromNode, toNode;
    string packetType;
    float srcAddr, toAddr;
    int packetId;
    int packetSize;
    int seqId;
    //globals
    // int toNodeFromArgv = atoi(argv[2]);
    // int fromNodeFromArgv = atoi(argv[3]);
    // string filename(argv[]);
    // string outfile(argv[4]);
    string temp;
    ifstream f("q2.tr");
    // 4,0 usually
    // end2EndDelay e2e(filename,toNodeFromArgv,fromNodeFromArgv);
    // packetDropRatio plr(outfile,toNodeFromArgv,fromNodeFromArgv);
    // packetDeliveryRatio pdr(outfile,toNodeFromArgv,fromNodeFromArgv);
    // controlOverhead co(outfile);
    throughPut tp("q2");
    // congestionControl cc(filename);

    while(getline(f, temp))
    {
        vector<string> tokens;
        strtok(temp, tokens);
        if(tokens.size()<12) continue;
        event = tokens[0][0];
        timestamp = stof(tokens[1]);
        fromNode = stoi(tokens[2]);
        toNode = stoi(tokens[3]);
        packetType = tokens[4];
        packetSize = stoi(tokens[5]);
        srcAddr = stof(tokens[8]);
        toAddr = stof(tokens[9]);
        seqId = stoi(tokens[10]);
        packetId = stoi(tokens[11]);

        tp.processPacketData(event,timestamp,toNode,seqId);
    }
    tp.printValues();
}

// r 0.20344  0.13048 0.21592